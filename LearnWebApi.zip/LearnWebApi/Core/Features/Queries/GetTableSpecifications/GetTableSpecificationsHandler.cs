using Core.Services;
using MediatR;
using Persistence.Models;
using Persistence.Repositories;
using StackExchange.Redis;
using System;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;

namespace Core.Features.Queries.GetTableSpecifications;

public class GetTableSpecificationsHandler : IRequestHandler<GetTableSpecificationsQuery, GetTableSpecificationsResponse>
{
    private readonly ITableSpecificationRepository _tableSpecificationRepository;
    private readonly RedisService<TableSpecification> _redisService;

    public GetTableSpecificationsHandler(ITableSpecificationRepository tableSpecificationRepository, RedisService<TableSpecification> redisService)
    {
        _tableSpecificationRepository = tableSpecificationRepository;
        _redisService = redisService;
    }

    public async Task<GetTableSpecificationsResponse> Handle(GetTableSpecificationsQuery query, CancellationToken cancellationToken)
    {
        //var tableSpecification = _tableSpecificationRepository.GetById(query.TableSpecificationId);

        // Key untuk Redis
        var cacheKey = $"TableSpecification:{query.TableSpecificationId}";

        // Cek apakah data ada di cache Redis
        var tableSpecification = await _redisService.GetDataAsync(cacheKey, _tableSpecificationRepository.GetById(query.TableSpecificationId));

        //if (!cachedData.IsNullOrEmpty)
        //{
        //    // Jika data ada di cache, deserialize dan return
        //    return JsonSerializer.Deserialize<GetTableSpecificationsResponse>(cachedData);
        //}

        if (tableSpecification is null)
            return new GetTableSpecificationsResponse();
        
        var response = new GetTableSpecificationsResponse()
        {
            TableId = tableSpecification.TableId,
            ChairNumber = tableSpecification.ChairNumber,
            TableNumber = tableSpecification.TableNumber,
            TablePic = tableSpecification.TablePic,
            TableType = tableSpecification.TableType
        };

   

        return response;
    }
}