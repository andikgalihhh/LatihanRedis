﻿using Azure;
using Core.Features.Queries.GetAllTableSpecifications;
using MediatR;
using Persistence.Models;
using Persistence.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using StackExchange.Redis;
using Core.Features.Queries.GetAllTableSpesifications;
using Core.Services;

namespace Core.Features.Queries.AddTableSpecifications;

public class AddTableSpecificationsHandler : IRequestHandler<AddTableSpecificationsQuery, AddTableSpecificationsResponse>
{
    private readonly ITableSpecificationRepository _tableSpecificationRepository;
    private readonly RedisService<TableSpecification> _redisService;
    public AddTableSpecificationsHandler(ITableSpecificationRepository tableSpecificationRepository, RedisService<TableSpecification> redisService)
    {
        _tableSpecificationRepository = tableSpecificationRepository;
        _redisService = redisService;
    }
    public async Task<AddTableSpecificationsResponse> Handle(AddTableSpecificationsQuery query, CancellationToken cancellationToken)
    {
     
        var newTableSpecification = new TableSpecification
        {
            ChairNumber = query.ChairNumber,
            TableNumber = query.TableNumber,
            TablePic = query.TablePic,
            TableType = query.TableType
        };

        string redisKey = $"TableSpecification:{newTableSpecification.TableId}";
        _tableSpecificationRepository.Add(newTableSpecification);
        await _redisService.CreateDataAsync(redisKey, _tableSpecificationRepository.GetById(id: newTableSpecification.TableId));

        var response = new AddTableSpecificationsResponse
        {
            TableId = newTableSpecification.TableId,
            TableNumber = newTableSpecification.TableNumber,
            ChairNumber = newTableSpecification.ChairNumber,
            TablePic = newTableSpecification.TablePic,
            TableType = newTableSpecification.TableType,
        };


        return response;

    }

    public Task<GetAllTableSpecificationsResponse> Handle(GetAllTableSpecificationsQuery request, CancellationToken cancellationToken)
    {
        throw new NotImplementedException();
    }
}

