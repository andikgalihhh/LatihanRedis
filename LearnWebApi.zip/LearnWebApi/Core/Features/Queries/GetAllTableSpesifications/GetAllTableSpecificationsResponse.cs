using Persistence.Models;

namespace Core.Features.Queries.GetAllTableSpecifications;

public class GetAllTableSpecificationsResponse
{
    public required List<TableSpecification> TableSpecifications { get; set; }
}

