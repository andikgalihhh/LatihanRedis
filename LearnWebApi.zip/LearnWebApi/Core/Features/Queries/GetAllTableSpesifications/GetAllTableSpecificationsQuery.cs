using Core.Features.Queries.GetAllTableSpecifications;
using MediatR;

namespace Core.Features.Queries.GetAllTableSpesifications;

public class GetAllTableSpecificationsQuery : IRequest<GetAllTableSpecificationsResponse>
{

}




