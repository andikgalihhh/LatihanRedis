using Core.Features.Queries.GetAllTableSpesifications;
using Core.Services;
using MediatR;
using Persistence.Models;
using Persistence.Repositories;
using StackExchange.Redis;
using System;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;

namespace Core.Features.Queries.GetAllTableSpecifications;

public class GetAllTableSpecificationsHandler : IRequestHandler<GetAllTableSpecificationsQuery, GetAllTableSpecificationsResponse>
{
    private readonly ITableSpecificationRepository _tableSpecificationRepository;
    private readonly RedisService<List<TableSpecification>> _redisService;

    public GetAllTableSpecificationsHandler(ITableSpecificationRepository tableSpecificationRepository, RedisService<List<TableSpecification>> redisService)
    {
        _tableSpecificationRepository = tableSpecificationRepository;
        _redisService = redisService;
    }

    public async Task<GetAllTableSpecificationsResponse> Handle(GetAllTableSpecificationsQuery query, CancellationToken cancellationToken)
    {
        // Key untuk Redis
        var cacheKey = $"TableSpecifications:All";

        // Cek apakah data ada di cache Redis, jika tidak ada ambil dari database dan simpan ke Redis
        var tableSpecifications = await _redisService.GetDataAsync(cacheKey, () => _tableSpecificationRepository.GetAll());

        if (tableSpecifications == null)
            return new GetAllTableSpecificationsResponse()
            {
                TableSpecifications = new List<TableSpecification>()
            };
        var response = new GetAllTableSpecificationsResponse()
        {
            TableSpecifications = tableSpecifications
        };

        return response;
    }
}