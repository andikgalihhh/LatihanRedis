using Microsoft.AspNetCore.Mvc;

namespace Application.Controllers;

[ApiController]
[Route("api")]
public class BaseController : ControllerBase
{
}