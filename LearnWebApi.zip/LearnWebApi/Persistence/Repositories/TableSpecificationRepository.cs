using Persistence.DatabaseContext;
using Persistence.Models;
using StackExchange.Redis;

namespace Persistence.Repositories
{

    public class TableSpecificationRepository : GenericRepository<TableSpecification>, ITableSpecificationRepository
    {
        public TableSpecificationRepository(TableContext context, IConnectionMultiplexer redisConnection) : base(context, redisConnection)
        {
        }
    }
}