using Persistence.DatabaseContext;
using StackExchange.Redis;
using System.Text.Json;

namespace Persistence.Repositories;

public class GenericRepository<T> : IGenericRepository<T> where T : class
{
    private readonly TableContext _context;
    private readonly IDatabase _cache;

    public GenericRepository(TableContext context, IConnectionMultiplexer redisConnection)
    {
        _context = context;
        _cache = redisConnection.GetDatabase();
    }

    public List<T> GetAll()
    {
        return _context.Set<T>().ToList();
    }

    public T? GetById(Guid id)
    {
        //return _context.Set<T>().Find(id);
        var cacheKey = $"{typeof(T).Name}:{id}";
        var cachedData = _cache.StringGet(cacheKey);

        if (!cachedData.IsNullOrEmpty)
        {
            return JsonSerializer.Deserialize<T>(cachedData);
        }

        var entity = _context.Set<T>().Find(id);

        if (entity != null)
        {
            var serializedData = JsonSerializer.Serialize(entity);
            _cache.StringSet(cacheKey, serializedData, TimeSpan.FromMinutes(10));
        }

        return entity;
    }

    public void Remove(T itemToRemove)
    {
        //_context.Set<T>().Remove(itemToRemove);
        _context.Set<T>().Remove(itemToRemove);

        var idProperty = itemToRemove.GetType().GetProperty("Id");
        if (idProperty != null)
        {
            var id = (Guid)idProperty.GetValue(itemToRemove);
            var cacheKey = $"{typeof(T).Name}:{id}";
            _cache.KeyDelete(cacheKey);
        }
    }
    public void Add(T itemToAdd)
    {
        //_context.Set<T>().Add(itemToAdd);
        _context.Set<T>().Add(itemToAdd);

        var idProperty = itemToAdd.GetType().GetProperty("Id");
        if (idProperty != null)
        {
            var id = (Guid)idProperty.GetValue(itemToAdd);
            var cacheKey = $"{typeof(T).Name}:{id}";
            var serializedData = JsonSerializer.Serialize(itemToAdd);
            _cache.StringSet(cacheKey, serializedData, TimeSpan.FromMinutes(10));
        }
    }
    public async Task<int> SaveChangesAsync(CancellationToken cancellationToken = default)
    {
        return await _context.SaveChangesAsync(cancellationToken);
    }

    public void Update(T item)
    {
        throw new NotImplementedException();
    }

    public T? GetByTableNumber(Guid TableNumber)
    {
        //return _context.Set<T>().Find(TableNumber);
        var cacheKey = $"{typeof(T).Name}:TableNumber:{TableNumber}";
        var cachedData = _cache.StringGet(cacheKey);

        if (!cachedData.IsNullOrEmpty)
        {
            return JsonSerializer.Deserialize<T>(cachedData);
        }

        var entity = _context.Set<T>().Find(TableNumber);

        if (entity != null)
        {
            var serializedData = JsonSerializer.Serialize(entity);
            _cache.StringSet(cacheKey, serializedData, TimeSpan.FromMinutes(10));
        }

        return entity;
    }

    public void Delete(T itemToRemove)
    {
        throw new NotImplementedException();
    }
    public interface IRedisService
    {
        Task<T?> GetAsync<T>(string key);
        Task SetAsync<T>(string key, T value, TimeSpan? expiry = null);
        Task<bool> RemoveAsync(string key);
    }

}
